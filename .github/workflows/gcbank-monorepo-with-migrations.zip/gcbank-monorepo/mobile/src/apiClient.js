import axios from 'axios';
import Constants from 'expo-constants';

const API_BASE = Constants.manifest?.extra?.apiBaseUrl || 'http://localhost:3000';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 5000,
});

export function setAuthToken(token){
  if (token) api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  else delete api.defaults.headers.common['Authorization'];
}

export default api;
